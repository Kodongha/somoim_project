package com.kh.somoim.run;

import com.kh.somoim.view.mainFrame.MainFrame;

public class Run {

	public static void main(String[] args) {
		
		new MainFrame();
		
	}
	
}
