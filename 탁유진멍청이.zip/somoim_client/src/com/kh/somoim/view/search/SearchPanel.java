package com.kh.somoim.view.search;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class SearchPanel extends JPanel {

	public SearchPanel() {
		// TODO Auto-generated constructor stub
		
		this.setBackground(Color.yellow);
		this.add(new JLabel("Search!!"), "1");
	}
	
}
