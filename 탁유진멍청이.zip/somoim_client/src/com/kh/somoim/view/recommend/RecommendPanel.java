package com.kh.somoim.view.recommend;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class RecommendPanel extends JPanel {
	
	public RecommendPanel() {
		// TODO Auto-generated constructor stub
		
		this.setBackground(Color.black);
		this.add(new JLabel("Recommend!!"), "1");
	}
	
}
