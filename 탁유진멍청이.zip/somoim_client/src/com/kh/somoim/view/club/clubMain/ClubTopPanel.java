package com.kh.somoim.view.club.clubMain;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class ClubTopPanel extends JPanel{
	
	public ClubTopPanel() {
		this.setBackground(Color.orange);
		this.setPreferredSize(new Dimension(500,100)); // ��� �г� ������ ����
		
	}
}
