package com.kh.somoim.view.club.clubMain;

import javax.swing.JPanel;

public class ClubCenterPanel extends JPanel{

}
