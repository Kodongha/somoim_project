package com.kh.somoim.view.home;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class HomePanel extends JPanel {
	
	public HomePanel() {
		// TODO Auto-generated constructor stub
		
		this.setBackground(Color.gray);
		this.add(new JLabel("Hoem!!"), "1");
	}
	
	
}
